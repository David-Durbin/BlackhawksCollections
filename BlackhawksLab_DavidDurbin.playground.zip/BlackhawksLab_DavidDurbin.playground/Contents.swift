//: Playground - noun: a place where people can play

import UIKit

// constant for number of players
let NUM_PLAYERS = 23

// Dictionary of players in 2016, organized by player number and name
let Players: [Int: String] = [15: "Artem Anisimov", 11: "Andrew Desjardins", 38: "Ryan Hartman", 48: "Vinnie Hinostroza", 81: "Marian Hossa", 88: "Patrick Kane", 67: "Tanner Kero", 16: "Marcus Kruger", 72: "Artemi Panarin", 14: "Richard Panik", 70: "Dennis Rasmussen", 8: "Nick Schmaltz", 19: "Jonathan Toews", 22: "Jordin Tootoo", 51: "Brian Campbell", 4: "Niklas Hjalmarsson", 2: "Duncan Keith", 6: "Michal Kempny", 32: "Michal Rozsival", 7: "Brent Seabrook", 57: "Trevor Van Riemsdyk", 50: "Corey Crawford", 33: "Scott Darling"]

// array of player ages
let playerAges: [Double] = [28, 30, 22, 22, 38, 28, 24, 26, 25, 26, 26, 20, 28, 34, 37, 29, 33, 26, 38, 31, 25, 32, 28]

// Players listed by country abreviation // 7 Americans and 7 Canadians, rest from Europe (WTF is SVK?)
let playerCountries: [String] = ["RUS", "CAN", "USA", "USA", "SVK", "USA", "USA", "SWE", "RUS", "SVK", "SWE", "USA", "CAN", "CAN", "CAN", "SWE", "CAN", "CZE", "CZE", "CAN", "USA", "CAN", "USA"]
//**********************************************************************************************\\
//**************************** Print Names *****************************************************\\

print(Players)

print()
//**********************************************************************************************\\
//**************************** Test Sort Players Country ***************************************\\

var sortedCountries: [String]



sortedCountries = playerCountries.sorted(by: <)

//print(sortedCountries)

print()
//**********************************************************************************************\\
//**************************** Calculate Average Age *******************************************\\

var averageAge: Double = 0

for (index, value) in playerAges.enumerated()
{
    averageAge = averageAge + value
}

averageAge = averageAge / Double(NUM_PLAYERS)

print("The average age of the Blackhawks players is \(Int(averageAge)) years old.")
print()
//**********************************************************************************************\\
//**************************** Calculate Average Height ****************************************\\

// player height (inches)
let playerHeight: [Int] = [88, 85, 84, 62, 85, 71, 84, 84, 71, 85, 87, 84, 84, 69, 70, 87, 85, 84, 85, 87, 86, 86, 90]
var heightFeet: Int = 0
var heightInches: Int = 0

// move through the array adding each player's height to heightInches
for (index, value) in playerHeight.enumerated()
{
    heightInches = heightInches + value
}

// divide by the total number of players to get the average in inches
heightInches /= NUM_PLAYERS

// divide the number of inches by 12 to get feet
heightFeet = heightInches / 12

// take the modulus of the heigh in inches by 12 to get the remaining inches
heightInches %= 12

// display average height
print("The average height of the Blalckhawks playeres is \(heightFeet) feet, \(heightInches) inches.")
print()
//**********************************************************************************************\\
//**************************** Player Birth Months *********************************************\\

// player birthday months // 3 may, 4 july, 3 sept, 3 April
let playerBirthMonths: [String] = ["May", "July", "Sept", "April", "Jan", "Nov", "July", "May", "Oct", "Feb", "April", "Feb", "May", "June", "July", "Sept", "Sept", "April", "July", "Dec", "Dec"]

var Jan: Int = 0, Feb: Int = 0, Mar: Int = 0, Apr: Int = 0, May: Int = 0, June: Int = 0
var July: Int = 0, Aug: Int = 0, Spt: Int = 0, Oct: Int = 0, Nov: Int = 0, Dec: Int = 0

for (index, value) in playerBirthMonths.enumerated()
{
   if value == "Jan"
   { Jan += 1 }
    else if value == "Feb"
   { Feb += 1 }
    else if value == "April"
   { Apr += 1 }
    else if value == "May"
   { May += 1 }
    else if value == "June"
   { June += 1 }
    else if value == "July"
   { July += 1 }
    else if value == "Sept"
   { Spt += 1 }
    else if value == "Oct"
   { Oct += 1 }
    else if value == "Nov"
   { Nov += 1 }
    else
   { Dec += 1 }
}

var Months: [String]

print("\(July) players were born in July")

print()
//**********************************************************************************************\\

// http://stackoverflow.com/questions/24090016/sort-dictionary-by-values-in-swift/24090641#24090641
let dict = [1:"apple", 3:"cake", 2:"banana"]

let byValue = {
    (elem1:(key: Int, val: String), elem2:(key: Int, val: String))->Bool in
    if elem1.val < elem2.val
    {
        return true
    }
    else
    {
        return false
    }
}
let sortedDict = Players.sorted(by: byValue)

print(sortedDict)
print()
//**********************************************************************************************\\

let dict2 = [1:"apple", 3:"cake", 2:"banana"]

let byKey = {
    (elem1:(key: Int, val: String), elem2:(key: Int, val: String))->Bool in
    if elem1.key < elem2.key
    {
        return true
    }
    else
    {
        return false
    }
}
let newSorted = Players.sorted(by: byKey)

print(newSorted)
print()
//**********************************************************************************************\\
